// const cache = { posts: null, comments: null };
// const url = 'http://localhost:3030/jsonstore/blog/';

// function createOption ({ id, title }) {
// 	const e = document.createElement('option');
// 	e.textContent = title;
// 	e.id = id;

// 	return e;
// }

// const clearOutput = (...arr) => arr.forEach(x => x.innerHTML = '');


// async function getData (uri) {
// 	const data = await fetch(`${url}${uri}`);

// 	return await data.json();
// }

// async function loadData (type) {
// 	if (cache[type] === null) {
// 		const data = await getData(type);
// 		console.log(data);
// 		cache[type] = data;
// 	}
// }

// async function displayPosts () {
// 	await loadData('posts');
// 	const selectElement = document.getElementById(`posts`);
// 	selectElement.innerHTML = '';

// 	Object.values(cache.posts).forEach(x => selectElement.appendChild(createOption(x)));
// }

// async function displayPost () {
// 	await loadData('comments');
// 	const html = {
// 		postTitle: document.getElementById(`post-title`),
// 		postBody: document.getElementById(`post-body`),
// 		postComments: document.getElementById(`post-comments`),
// 		selectElement: document.getElementById(`posts`)
// 	}
// 	const selected = html.selectElement.options[html.selectElement.selectedIndex];
// 	const comments = Object.values(cache.comments).filter(x => x.postId === selected.id);

// 	clearOutput(html.postTitle, html.postBody, html.postComments);

// 	html.postTitle.textContent = selected.value;
// 	html.postBody.textContent = cache.posts[selected.id].body;
// 	html.postComments.innerHTML = comments.map(x => `<li id=${x.id}>${x.text}</li>`).join('');
// }

// function attachEvents () {
// 	document.addEventListener('click', e => {
// 		if (e.target.tagName === 'BUTTON') {
// 			const btns = {
// 				'btnViewPost': displayPost,
// 				'btnLoadPosts': displayPosts,
// 			}

// 			btns[e.target.id]();
// 		}
// 	});
// }

// attachEvents();

function attachEvents() {
	document.getElementById('btnLoadPosts').addEventListener('click', loadPosts);
	document.getElementById('btnViewPost').addEventListener('click', viewPost);

	const posts = [];
	async function loadPosts() {
		try {
			const url = 'http://localhost:3030/jsonstore/blog/posts';
			const res = await fetch(url);
			if (!res.ok) {
				throw new Error();
			}
			const data = await res.json();
			document.getElementById(`posts`).innerHTML = '';

			Object.entries(data).forEach(([key, value]) => {
				const optionElement = document.createElement('option');
				optionElement.value = key;
				optionElement.textContent = value.title;
				document.getElementById(`posts`).appendChild(optionElement);
				posts.push({ title: value.title, body: value.body });
			});
		} catch (e) {
			console.log(e);
		}
	}

	async function viewPost() {
		try {
			const selectElement = document.getElementById('posts');
			const url = 'http://localhost:3030/jsonstore/blog/comments';
			const res = await fetch(url);
			if (!res.ok) {
				throw new Error();
			}
			const data = await res.json();
            const comments = Object.values(data).filter(el => el.postId === selectElement.value);

			document.getElementById('post-title').textContent = selectElement.selectedOptions[0].textContent;
			const po = posts.filter(p => p.title === selectElement.selectedOptions[0].textContent);
		
			document.getElementById('post-body').innerHTML = `${po[0].body}`;
			document.getElementById('post-comments').innerHTML = '';

			comments.forEach(el => {
				const liElement = document.createElement('li');
				liElement.textContent = el.text;
				document.getElementById('post-comments').appendChild(liElement);
			})
		} catch (e) {
           console.log(e);
		}
	}
}

attachEvents();