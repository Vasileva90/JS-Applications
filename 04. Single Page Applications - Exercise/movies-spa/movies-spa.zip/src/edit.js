import { showView } from './util.js';

const section = document.querySelector('#edit-movie');


export function editPage() {
    showView(section);
}