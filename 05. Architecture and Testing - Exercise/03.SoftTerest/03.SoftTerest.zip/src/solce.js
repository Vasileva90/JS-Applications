function solce(){
    return 1;
}
 console.log(solce());